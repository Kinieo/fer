#!/usr/bin/env python3
import subprocess

def get_default_gateway():
    try:
        result = subprocess.check_output("ip r | grep default", shell=True, text=True)
        gateway = result.split()[2]
        return gateway
    except subprocess.CalledProcessError:
        print("Error: Could not determine default gateway.")
        return None
    except IndexError:
        print("Error: Unexpected output format.")
        return None

while True:
    print("\nMenu:")
    print("1. Display the default gateway")
    print("2. Test Local Connectivity")
    print("3. Test Remote Connectivity")
    print("4. Test DNS Resolution")
    print("5. Exit/quit the script")

    choice = input("Enter your choice: (enter a single number ex: 1) ")

    if choice == "1":
        gateway = get_default_gateway()
        if gateway:
            print("Default gateway:", gateway)

    elif choice == "2":
        gateway = get_default_gateway()
        if gateway:
            print("Pinging local gateway...")
            try:
                subprocess.run(["ping", "-c", "4", gateway], check=True)
            except subprocess.CalledProcessError:
                print("Error: Failed to ping local gateway.")

    elif choice == "3":
        print("Pinging remote IP 192.21.3.17...")
        try:
            subprocess.run(["ping", "-c", "4", "192.21.3.17"], check=True)
        except subprocess.CalledProcessError:
            print("Error: Failed to ping remote IP.")

    elif choice == "4":
        print("Testing DNS resolution (pinging google.com)...")
        try:
            subprocess.run(["ping", "-c", "4", "google.com"], check=True)
        except subprocess.CalledProcessError:
            print("Error: DNS resolution or connection failed.")

    elif choice == "5":
        print("Exiting the script.")
        break

    else:
        print("Invalid choice. Please enter a number between 1 and 5.")

