#!/usr/bin/env python3
# Author: Jack Dollyhigh
# Date: October 23/24 2025
# Description: Menu driven script to manage symbolic links on Linux (Rocky 9)

import os
import pathlib
import shutil
#clears terminal
def clear_screen():
    os.system('clear' if os.name == 'posix' else 'cls')
#shows intro and cur dir
def show_intro():
    clear_screen()
    print("=== Symbolic Link Manager ===\n")
    print(f"Current working directory: {os.getcwd()}")
    print(f"Home directory: {pathlib.Path.home()}\n")

def create_symlink():
    home = pathlib.Path.home()
    desktop = home / "Desktop"

    print("\n--- Create a Symbolic Link ---")

    # Ask for file to link
    target_path = input("Enter the full path of the file you want to link to: ").strip()
    target = pathlib.Path(target_path)

    # Check that it exists
    if not target.exists():
        print("Error: The file does not exist. Please check the path and try again.\n")
        return

    # Ask for link name
    link_name = input("Enter a name for the symbolic link (without path): ").strip()
    link_path = desktop / link_name

    # Prevent overwriting
    if link_path.exists():
        print("Error: A file or link with that name already exists on your Desktop.\n")
        return

    try:
	#this line creates the link
        os.symlink(target, link_path)
        print(f"Success! Created symbolic link on Desktop:\n→ {link_path} → {target}\n")
    except PermissionError:
        print("Error: Permission denied. Try running the script with sufficient privileges.\n")
    except Exception as e:
        print(f"Unexpected error: {e}\n")
#menu code
def main_menu():
    while True:
        print("Select an option below:")
        print("[1] Create a symbolic link")
        print("[2] Delete a symbolic link")
        print("[3] Generate a symbolic link report")
        print("[4] Quit")
        print()

        choice = input("Enter your choice (1-4 or 'quit'): ").strip().lower()

        if choice in ('4', 'quit'):
            print("\nExiting Symbolic Link Manager. Goodbye!")
            break
        elif choice == '1':
            create_symlink()
        elif choice == '2':
            delete_symlink()
        elif choice == '3':
            generate_report()
        else:
            print("Invalid input. Please try again.\n")
def delete_symlink():
    home = pathlib.Path.home()
    desktop = home / "Desktop"

    print("\n--- Delete a Symbolic Link ---")

    link_name = input("Enter the name of the symbolic link on your Desktop: ").strip()
    link_path = desktop / link_name

    # Check if it exists
    if not link_path.exists():
        print("Error: No file or link with that name exists on your Desktop.\n")
        return

    # Ensure it’s actually a symlink
    if not link_path.is_symlink():
        print("Error: That file exists but is not a symbolic link. Only symbolic links can be deleted here.\n")
        return

    try:
	#this line actually deletes the link
        link_path.unlink()
        print(f"Success! Deleted symbolic link: {link_path}\n")
    except PermissionError:
        print("Error: Permission denied. Try running the script with sufficient privileges.\n")
    except Exception as e:
        print(f"Unexpected error: {e}\n")
def generate_report():
    home = pathlib.Path.home()
    desktop = home / "Desktop"

    print("\n--- Symbolic Link Report ---\n")

    # Find all symlinks in home directory (recursive algo)
    symlinks = []
    for path in home.rglob('*'):
        if path.is_symlink():
            symlinks.append(path)

    # Count them
    total_links = len(symlinks)

    # Filter Desktop links for a neat list
    desktop_links = [p for p in symlinks if p.parent == desktop]

    if not desktop_links:
        print("No symbolic links found on your Desktop.\n")
    else:
        print("Symbolic links on your Desktop:")
        for link in desktop_links:
            try:
                target = link.resolve(strict=False)
                print(f"• {link.name} → {target}")
            except Exception:
                print(f"• {link.name} → [Broken link]")
        print()

    print(f"Total symbolic links in your home directory: {total_links}\n")

if __name__ == "__main__":
    show_intro()
    main_menu()
