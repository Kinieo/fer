#!/usr/bin/env python3
# Student: Jack Dollyhigh
# Date: 9/19/2025 11:30 AM

from datetime import datetime
import socket
import os
import shutil
import ipaddress
#clears the terminal
os.system("clear")
# Prepare log file in home directory
hostname = socket.gethostname()
home_dir = os.path.expanduser("~")
log_path = os.path.join(home_dir, f"{hostname}_system_report.log")

# Open log file
log_file = open(log_path, "w")

# Function to print to screen + log
def log_print(message=""):
    print(message)
    print(message, file=log_file)

# --- Report start ---
current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
log_print("=============================================")
log_print("        System Information Report")
log_print("=============================================")
log_print(f"Date: {current_date}")
log_print()

# Device info
log_print("---- Device Information ----")
fqdn = socket.getfqdn()
domain_suffix = fqdn.split('.', 1)[1] if fqdn != hostname else "N/A"
log_print(f"Host Name: {hostname}")
log_print(f"Domain Suffix: {domain_suffix}")
log_print()

# Network info
log_print("---- Network Information ----")

# IPv4 Address (skip loopback)
with os.popen("hostname -I | awk '{print $1}'") as f:
    ipv4 = f.read().strip()

# Default Gateway
with os.popen("ip route | grep default | awk '{print $3}'") as f:
    gateway = f.read().strip()

# Network Mask (convert CIDR -> dotted netmask, skip loopback)
with os.popen("ip -o -f inet addr show | grep -v '127.0.0.1' | awk '{print $4}' | head -n1") as f:
    cidr = f.read().strip()

try:
    netmask = str(ipaddress.ip_network(cidr, strict=False).netmask)
except ValueError:
    netmask = "N/A"

# DNS servers
dns = []
with open("/etc/resolv.conf") as f:
    for line in f:
        if line.startswith("nameserver"):
            dns.append(line.split()[1])

dns1 = dns[0] if len(dns) > 0 else "N/A"
dns2 = dns[1] if len(dns) > 1 else "N/A"

log_print(f"IPv4 Address: {ipv4 if ipv4 else 'N/A'}")
log_print(f"Default Gateway: {gateway if gateway else 'N/A'}")
log_print(f"Network Mask: {netmask if netmask else 'N/A'}")
log_print(f"Primary DNS: {dns1}")
log_print(f"Secondary DNS: {dns2}")
log_print()

# OS info
log_print("---- Operating System Information ----")
os_name = "N/A"
os_version = "N/A"
try:
    with open("/etc/os-release") as f:
        for line in f:
            if line.startswith("NAME=") and os_name == "N/A":
                os_name = line.strip().split("=")[1].strip('"')
            if line.startswith("VERSION="):
                os_version = line.strip().split("=")[1].strip('"')
except FileNotFoundError:
    pass

with os.popen("uname -r") as f:
    kernel_version = f.read().strip()

log_print(f"Operating System: {os_name}")
log_print(f"OS Version: {os_version}")
log_print(f"Kernel Version: {kernel_version}")
log_print()

# Storage info
log_print("---- Storage Information ----")
total, used, free = shutil.disk_usage("/")
gb = 1024**3
log_print(f"System Disk Total: {total // gb} GB")
log_print(f"System Disk Used: {used // gb} GB")
log_print(f"System Disk Free: {free // gb} GB")
log_print()

# CPU info
log_print("---- Processor Information ----")
cpu_model = "N/A"
try:
    with open("/proc/cpuinfo") as f:
        for line in f:
            if line.strip().startswith("model name"):
                cpu_model = line.split(":", 1)[1].strip()
                break
except FileNotFoundError:
    pass

num_processors = os.cpu_count()
num_cores = "N/A"
try:
    with open("/proc/cpuinfo") as f:
        for line in f:
            if line.strip().startswith("cpu cores"):
                num_cores = line.split(":", 1)[1].strip()
                break
except FileNotFoundError:
    pass

log_print(f"CPU Model: {cpu_model}")
log_print(f"Number of Processors: {num_processors}")
log_print(f"Number of CPU Cores: {num_cores}")
log_print()

# Memory info
log_print("---- Memory Information ----")
total_ram = "N/A"
available_ram = "N/A"
try:
    with open("/proc/meminfo") as f:
        for line in f:
            if line.startswith("MemTotal:"):
                total_ram = int(line.split()[1]) // 1024
            elif line.startswith("MemAvailable:"):
                available_ram = int(line.split()[1]) // 1024
except FileNotFoundError:
    pass

log_print(f"Total RAM: {total_ram} MB")
log_print(f"Available RAM: {available_ram} MB")
log_print()

# Close log file
log_file.close()
print(f"\nReport also saved to: {log_path}")
